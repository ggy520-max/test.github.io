#include "Autosprite.h"

Autosprite::Autosprite(int x, int y, int width, int height, int dx, int dy, ACL_Image *img, rect r, int score)
	:SpriteBase(x, y, width, height, dx, dy, img, r) {
	this->score = score;
}
Autosprite::Autosprite(Autosprite&sprite) : SpriteBase(sprite) {
	score = sprite.score;
}
Autosprite::~Autosprite() {

}

int Autosprite::getScore() {
	return score;
}
void Autosprite::move(rect ur) {
	if (x<r.x || x>(r.x + r.width - width))dx = -1;
	if (y<r.y || y>(r.y + r.height - height))dy = -1;
	if (score == 48 || score == 66) { dx += 1; dy += 1; }
	x += dx;
	y += dy;
}
