#include "AvoidSprite.h"
#include<math.h>

AvoidSprite::AvoidSprite(int x, int y, int width, int height, int dx, int dy, ACL_Image *img, rect r, int score)
	:Autosprite(x, y, width, height, dx, dy, img, r, score) {
	oldx = dx;
	oldy = dy;
}
AvoidSprite::AvoidSprite(AvoidSprite&sprite):Autosprite(sprite){
	oldx = dx;
	oldy = dy;
}
AvoidSprite::~AvoidSprite(){}
void AvoidSprite::move(rect r1) {//��ܾ�����ƶ�
	if (mynear(r1)) {
		if (c) {
			dx *= 2; dy *= 2;
			c=0;
		}
		if (x < r1.x)dx = -abs(dx);
		else dx = abs(dx);
		if (y < r1.y)dy = -abs(dy);
		else dy = abs(dy);
		if (score == 48 || score == 66) {
			dx += 1; dy += 1;
		}
		x += dx; y += dy;
		if (x < r.x)x = r.x + r.width - width;
		if (x > r.x + r.width - width)x = r.x;
		if (y < r.y)y = r.y + r.height - height;
		if (y > r.y + r.height - height)y = r.y;
	}
	else {
		dx = oldx; dy = oldy;	
		c=1;
		Autosprite::move(r);
	}
}
bool AvoidSprite::mynear(rect r) {//������û�����ľ���
	int a = (x + width) / 2;
	int b = (y + height) / 2;
	int c = (r.x + r.width) / 2;
	int d = (r.y + r.height) / 2;
	double dist = sqrt((a - c) * (a-c) + (b - d) * (b-d));
	if (dist < 150)return true;
	else return false;
}

