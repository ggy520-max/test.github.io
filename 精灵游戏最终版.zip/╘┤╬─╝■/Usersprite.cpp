#include "Usersprite.h"

Usersprite::Usersprite(int x, int y, int width, int height, int dx, int dy, ACL_Image *img, rect r,int score)
	:SpriteBase(x, y, width, height, dx, dy, img, r) {
	this->score = score; x2 = x; y2 = y;
}
Usersprite::Usersprite(Usersprite&sprite) : SpriteBase(sprite) {
	this->score = score;
}
Usersprite::~Usersprite() {

}
void Usersprite::move(rect r) {

}
//�û�������ƶ�
void Usersprite::move(int key) {
	switch (score) {
	case 8:dx += 0; dy += 1; break;//y�����ٶ���1
	case 24:dx += 1; dy += 0; break;//x�����ٶ���1
	case 48:dx += 0; dy += 1; break;
	case 66:dx += 1; dy += 1; break;
	case 80:dx = 3; dy = 3; break;
	}
	switch (key)//���̿��Ʒ���
	{
	case VK_UP:

		y -= dy;
		if (y < r.y)y = r.y;
		break;
	case VK_DOWN:

		y += dy; 
		if (y > (r.y + r.height - height))y = r.y + r.height - height;
		break;
	case VK_LEFT:

		x -= dx; 
		if (x < r.x)x = r.x;
		break;
	case VK_RIGHT:

		x += dx; 
		if (x > (r.x + r.width - width))x = r.x + r.width - width;
		break;
	}
	
}
void Usersprite::move(int xx, int yy) {//�ƶ�
	x = xx;
	y = yy;
	if (x < r.x)x = r.x;
	if (x > (r.x + r.width - width))x = (r.x + r.width - width);
	if (y < r.y)y = r.y;
	if (y > (r.y + r.height - height))y = (r.y + r.height - height);
}
int Usersprite::collision(rect r2) {//�����ײ
	rect r1 = { x,y, width, height };
	int c = 1;
	if (r1.x < r2.x && r1.x + r1.width >r2.x) {
		if (r1.y > r2.y && r1.y < r2.y + r2.height)return c;
		if (r1.y <r2.y && r1.y + r1.height >r2.y)return c;
	}
	else {
		if (r1.x > r2.x && r2.x + r2.width > r1.x)
		{
			if (r1.y > r2.y && r1.y < r2.y + r2.height)return c;
			if (r1.y <r2.y && r1.y + r1.height >r2.y)return c;
		}
	}
	c = 0;
	return c;
}
int Usersprite::getScore() {
	return score;
}
void Usersprite::setScore(int s) {
	score = s;
}
void Usersprite::addScore(int m) {
	score += m;
}
int Usersprite::getx() {
	return x2;
}
int Usersprite::gety() {
	return y2;
}
