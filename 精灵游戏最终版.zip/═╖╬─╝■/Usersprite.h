#pragma once
#include "SpriteBase.h"
class Usersprite :
	public SpriteBase
{
protected:
	int score;
	int dx1, dy1, x2, y2;

public:
	
	Usersprite(int x, int y, int width, int height, int dx, int dy, ACL_Image *img, rect r,int score);
	Usersprite(Usersprite&sprite);
	~Usersprite();
	void move(rect r);
	void move(int key);
	void move(int xx, int yy);
	int collision(rect r2);
	int getScore();
	void setScore(int s);
	void addScore(int m);
	int getx();
	int gety();
};

