#pragma once
#include "Autosprite.h"
class AvoidSprite :
	public Autosprite
{
	int oldx, oldy;
	int c = 1;
	
public:
	AvoidSprite(int x, int y, int width, int height, int dx, int dy, ACL_Image *img, rect r,int score);
	AvoidSprite(AvoidSprite&sprite);
	virtual ~AvoidSprite();
	void move(rect r);
	bool mynear(rect r);
	
};

