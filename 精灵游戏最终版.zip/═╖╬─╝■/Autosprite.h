#pragma once
#include "SpriteBase.h"
class Autosprite :
	public SpriteBase
{
protected:
	int score;
public:
	Autosprite(int x, int y, int width, int height, int dx, int dy, ACL_Image *img, rect r,int score);
	Autosprite(Autosprite &sprite);
	~Autosprite();
	void move(rect r);
	int getScore();
};

